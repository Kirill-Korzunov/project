#!/usr/bin/env python3

def main():
    print('Добро пожаловать в игры разума!')

if __name__ == '__main__':
    main()